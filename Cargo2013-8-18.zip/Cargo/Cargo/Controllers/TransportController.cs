﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace Cargo.Controllers
{
    public class TransportController : Controller
    {
        //
        // GET: /Transport/

        public ActionResult Index()
        {
           
            return View();
        }

        public ActionResult Strength()
        {
            return PartialView("_Strength");
        }
        public ActionResult BargeScale()
        {
            return PartialView("_BargeScale");
        }
        public ActionResult LDT()
        {
            return PartialView("_LDT");
        }
    }
}
