﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Cargo.Models
{
    public class BaseEntityModel
    {
        public virtual int Id { get; set; }
    }
}