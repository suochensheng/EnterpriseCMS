﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Web.Framework.UI
{
    public enum NotifyTypeEnum
    {
        Success,
        Error
    }
}
